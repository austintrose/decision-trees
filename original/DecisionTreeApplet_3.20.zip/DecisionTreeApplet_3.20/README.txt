Decision Tree Applet version 3.01.

Released November 2000.
-----------------------------------------------------------

This archive should contain both the .java source files
and the .class object files for the Decision Tree Applet.
The applet is distributed under the GPL.  You should also
have received a copy of the GPL in this archive (the file
COPYING.txt).

I used the JBuilder IDE to develop the applet. A JBuilder 
project file is included in the root directory of the 
archive.  The personal version of JBuilder is available
free of charge, for Windows and Linux, at www.borland.com.

There is a brief design document (in MS Word format) 
located in the /manual directory.  Additionally, all of
the source files are commented - you should be able to
build documentation for each of the four applet packages
using the Javadoc utility.

Please send comments and bug reports to 
jkelly@cs.ualberta.ca.

Enjoy!

Jonathan Kelly (jkelly@cs.ualberta.ca)
August 18, 2002.

-----------------------------------------------------------